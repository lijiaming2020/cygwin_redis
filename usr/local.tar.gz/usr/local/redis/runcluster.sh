#! /bin/bash
./bin/redis-server /usr/local/redis-cluster/7001/7001.conf
./bin/redis-server /usr/local/redis-cluster/7002/7002.conf
./bin/redis-server /usr/local/redis-cluster/7003/7003.conf
./bin/redis-server /usr/local/redis-cluster/7004/7004.conf
./bin/redis-server /usr/local/redis-cluster/7005/7005.conf
./bin/redis-server /usr/local/redis-cluster/7006/7006.conf
